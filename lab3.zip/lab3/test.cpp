#include <iostream>
#include "Tree.h" 

int main() {

    Tree c_sum, c_a, c_b;

    c_a.buildFromString("+ 1 1 2 +");
    c_b.buildFromString("/ a 0");

    std::cout << "\nStan poczatkowy:" << std::endl;
    std::cout << "c_a: " << c_a.printPrefix() << std::endl;
    std::cout << "c_b: " << c_b.printPrefix() << std::endl;
    std::cout << "c_sum: " << c_sum.printPrefix() << std::endl;

    std::cout << "\nWykonuje operacje c_sum = c_a + c_b;" << std::endl;
    c_sum = c_a + c_b;

std::cout << "\nc_sum po operacji: " << c_sum.printPrefix() << std::endl;
std::cout << "c_a po operacji: " << c_a.printPrefix() << std::endl;
std::cout << "c_b po operacji: " << c_b.printPrefix() << std::endl;



    if ("+ / a 0 b" == c_sum.printPrefix()) {
        std::cout << "[PASS] " << "c_sum po operacji" << std::endl;
    }
    if ("+ a b" == c_a.printPrefix()) {
        std::cout << "[PASS] " << "c_a po operacji" << std::endl;
    }
    if ("/ a 0" == c_b.printPrefix()) {
        std::cout << "[PASS] " << "c_b po operacji" << std::endl;
    }
    std::cout << "\nKoniec testu" << std::endl;

    return 0;
}
//g++ test.cpp App.cpp Tree.cpp Node.cpp NodeCreator.cpp Error.cpp -o Tester