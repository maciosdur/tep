#pragma once
#include <iostream>

class CSellData {
public:
    CSellData() {}

    void vPrintData() {
        std::cout << "Data printed!\n";
    }
};
