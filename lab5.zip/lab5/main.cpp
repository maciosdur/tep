#include "App.h"

int main() {
    App app;
    app.run();
    return 0;
}
//g++ -std=c++98 main.cpp App.cpp Tree.cpp Node.cpp NodeCreator.cpp Error.cpp -o calculator
