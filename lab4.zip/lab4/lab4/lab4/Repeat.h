template<typename T, unsigned N>
struct Repeat {
    typedef T ValueType;   // alias wymagany w treści zadania

    T operator()(const T& value) const {
        T result = T();   // startujemy od wartości "zerowej" typu T
        for(unsigned i = 0; i < N; ++i) {
            result = result + value;
        }
        return result;
    }
};